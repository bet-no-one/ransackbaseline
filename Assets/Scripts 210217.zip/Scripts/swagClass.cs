﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class swagClass : MonoBehaviour {
    public int swagValue;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

	}

}
